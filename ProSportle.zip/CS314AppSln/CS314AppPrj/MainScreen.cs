﻿using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace CS314AppPrj
{
    public partial class MainScreen : Form
    {
        //declare child forms for this form
        HelpForm helpForm;
        ResetForm resetForm;
        LoginForm loginForm;
        //AccountForm accountForm;


        //variables
        private int num; //number that the computer generated
        private int i; //index for guessing player in excel sheet
        private int j = 1; //number of panels (8)
        private int k; //index for guessed player in excel sheet
        private int ctr = 1; //counter
        private List<string> guessPlayer = new List<string>();
        private List<string> gameData = new List<string>();
        private Workbook wb;
        private Worksheet ws;
        private string filePath = "C:/Users/arian/OneDrive/Desktop/NBA Database.xlsx";
        private string guess;

        public MainScreen()
        {
            InitializeComponent();
        }

        private void helpButton_Click(object sender, EventArgs e) //button to open help window
        {
            if (null == helpForm || helpForm.IsDisposed)
            {
                helpForm = new HelpForm();
            } //check if help form exists

            helpForm.Enabled = false; //help form will open in view-only mode
            helpForm.Show(); //open the help form
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            if (null == resetForm || resetForm.IsDisposed)
            {
                resetForm = new ResetForm();
            } //check if reset form exists

            //resetForm.Enabled = false; //reset form will open in view-only mode
            resetForm.Show(); //open the reset form
        }

        public void StartButton_Click(object sender, EventArgs e)
        {
            generateRandom();
            guessingPlayer();
            MessageBox.Show("Welcome to ProSportle!\nTry to guess an NBA or NFL Player in eight guesses.\n");
        }
        public void generateRandom() //generates random number that will correspond to player in excel sheet
        {
            Random rnd = new Random();
            num = rnd.Next(1, 122);
        }

        public void guessingPlayer() //function to read in guessing player data from excel
        {
            
            {
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();

                wb = excel.Workbooks.Open(filePath); //set workbook variable to excel sheet
                ws = wb.Worksheets[1]; //sets variable worksheet to the first worksheet in the excel workbook

                //create a dictionary that stores the info of the player the user is trying to guess
                int i = num;

                for (int a = 2; a < 10; a++)
                {
                    Range cell = ws.Cells[i, a];
                    string item = cell.Value.ToString(); //item is equal to value of that cell
                    guessPlayer.Add(item); //add item in each cell to list
                }

                gameData.Add("Player to guess: ");
                gameData.Add(guessPlayer[0]); //add the first name of the player you're trying to guess to game data list    
            }
        }

        public void enterButton_Click_1(object sender, EventArgs e)
        {
            guess = guessBox.Text;

            Excel.Application excel = null;
            excel = new Excel.Application();
            excel.Visible = false;
            Excel.Workbook wb = null;


            wb = excel.Workbooks.Open(filePath); //set workbook variable to excel sheet
            Excel.Range searchedRange = excel.get_Range("B2", "B123");
            Excel.Range currentFind = searchedRange.Find(guess);
            string result = "";

            if (guessPlayer.Count == 0)
            {
                MessageBox.Show("Click the Start Button to begin.");
            }

            else
            {
                if (currentFind != null) //if the currentFind is not empty
                {
                    int guessedPlayerNum = currentFind.Row; //number of the guessed player set to the row of the guessed player - 1
                    result = currentFind.Column.ToString() + " " + currentFind.Row.ToString(); //result is equal to location of the guessed name (column, row)

                    int k = guessedPlayerNum;
                    List<string> guessedPlayer = new List<string>(); //declares new list that will hold all info of player user is trying to guess

                    for (int a = 2; a < 10; a++)
                    {
                        Range cell = ws.Cells[k, a];
                        string item = cell.Value.ToString(); //item is equal to value of that cell
                        guessedPlayer.Add(item); //add item in each cell to list
                    }

                    gameData.Add("Guessed Player: ");
                    gameData.Add(guessedPlayer[0]); //add first name of guessed player to game data list
                    MessageBox.Show(string.Join(Environment.NewLine, gameData));

                    if (j != 9)
                    {
                        if (guessPlayer[0] != guessedPlayer[0]) //if the names are not equal 
                        {
                            if (ctr == 1) //panel 1
                            {
                                nrtb1.Text = guessedPlayer[0].ToString();
                                if (guessPlayer[0].ToString() == guessedPlayer[0].ToString()) //if the conference is correct
                                {
                                    nrtb1.BackColor = Color.Green;
                                }
                                crtb1.Text = guessedPlayer[1].ToString();
                                if (guessPlayer[1].ToString() == guessedPlayer[1].ToString()) //if the conference is correct
                                {
                                    crtb1.BackColor = Color.Green;
                                }
                                drtb1.Text = guessedPlayer[2].ToString();
                                if (guessPlayer[2].ToString() == guessedPlayer[2].ToString()) //if the division is correct
                                {
                                    drtb1.BackColor = Color.Green;
                                }
                                trtb1.Text = guessedPlayer[3].ToString();
                                if (guessPlayer[3].ToString() == guessedPlayer[3].ToString()) //if the team is correct
                                {
                                    trtb1.BackColor = Color.Green;
                                }
                                artb1.Text = guessedPlayer[4].ToString();
                                if (guessPlayer[4].ToString() == guessedPlayer[4].ToString()) //if the age is correct
                                {
                                    artb1.BackColor = Color.Green;
                                }
                                hrtb1.Text = guessedPlayer[5].ToString();
                                if (guessPlayer[5].ToString() == guessedPlayer[5].ToString()) //if the height is correct
                                {
                                    hrtb1.BackColor = Color.Green;
                                }
                                prtb1.Text = guessedPlayer[6].ToString();
                                if (guessPlayer[6].ToString() == guessedPlayer[6].ToString()) //if position is correct
                                {
                                    prtb1.BackColor = Color.Green;
                                }
                                jrtb1.Text = guessedPlayer[7].ToString();
                                if (guessPlayer[7].ToString() == guessedPlayer[7].ToString()) //if jersey no. is correct
                                {
                                    jrtb1.BackColor = Color.Green;
                                }
                            }

                            else if (ctr == 2) //panel 2
                            {
                                nrtb2.Text = guessedPlayer[0].ToString();
                                if (guessPlayer[0].ToString() == guessedPlayer[0].ToString()) //if the conference is correct
                                {
                                    nrtb2.BackColor = Color.Green;
                                }
                                crtb2.Text = guessedPlayer[1].ToString();
                                if (guessPlayer[1].ToString() == guessedPlayer[1].ToString()) //if the conference is correct
                                {
                                    crtb2.BackColor = Color.Green;
                                }
                                drtb2.Text = guessedPlayer[2].ToString();
                                if (guessPlayer[2].ToString() == guessedPlayer[2].ToString()) //if the division is correct
                                {
                                    drtb2.BackColor = Color.Green;
                                }
                                trtb2.Text = guessedPlayer[3].ToString();
                                if (guessPlayer[3].ToString() == guessedPlayer[3].ToString()) //if the team is correct
                                {
                                    trtb2.BackColor = Color.Green;
                                }
                                artb2.Text = guessedPlayer[4].ToString();
                                if (guessPlayer[4].ToString() == guessedPlayer[4].ToString()) //if the age is correct
                                {
                                    artb2.BackColor = Color.Green;
                                }
                                hrtb2.Text = guessedPlayer[5].ToString();
                                if (guessPlayer[5].ToString() == guessedPlayer[5].ToString()) //if the height is correct
                                {
                                    hrtb2.BackColor = Color.Green;
                                }
                                prtb2.Text = guessedPlayer[6].ToString();
                                if (guessPlayer[6].ToString() == guessedPlayer[6].ToString()) //if position is correct
                                {
                                    prtb2.BackColor = Color.Green;
                                }
                                jrtb2.Text = guessedPlayer[7].ToString();
                                if (guessPlayer[7].ToString() == guessedPlayer[7].ToString()) //if jersey no. is correct
                                {
                                    jrtb2.BackColor = Color.Green;
                                }
                            }

                            else if (ctr == 3) //panel 3
                            {
                                nrtb3.Text = guessedPlayer[0].ToString();
                                if (guessPlayer[0].ToString() == guessedPlayer[0].ToString()) //if the conference is correct
                                {
                                    nrtb3.BackColor = Color.Green;
                                }
                                crtb3.Text = guessedPlayer[1].ToString();
                                if (guessPlayer[1].ToString() == guessedPlayer[1].ToString()) //if the conference is correct
                                {
                                    crtb3.BackColor = Color.Green;
                                }
                                drtb3.Text = guessedPlayer[2].ToString();
                                if (guessPlayer[2].ToString() == guessedPlayer[2].ToString()) //if the division is correct
                                {
                                    drtb3.BackColor = Color.Green;
                                }
                                trtb3.Text = guessedPlayer[3].ToString();
                                if (guessPlayer[3].ToString() == guessedPlayer[3].ToString()) //if the team is correct
                                {
                                    trtb3.BackColor = Color.Green;
                                }
                                artb3.Text = guessedPlayer[4].ToString();
                                if (guessPlayer[4].ToString() == guessedPlayer[4].ToString()) //if the age is correct
                                {
                                    artb3.BackColor = Color.Green;
                                }
                                hrtb3.Text = guessedPlayer[5].ToString();
                                if (guessPlayer[5].ToString() == guessedPlayer[5].ToString()) //if the height is correct
                                {
                                    hrtb3.BackColor = Color.Green;
                                }
                                prtb3.Text = guessedPlayer[6].ToString();
                                if (guessPlayer[6].ToString() == guessedPlayer[6].ToString()) //if position is correct
                                {
                                    prtb3.BackColor = Color.Green;
                                }
                                jrtb3.Text = guessedPlayer[7].ToString();
                                if (guessPlayer[7].ToString() == guessedPlayer[7].ToString()) //if jersey no. is correct
                                {
                                    jrtb3.BackColor = Color.Green;
                                }
                            }

                            else if (ctr == 4) //panel 4
                            {
                                nrtb4.Text = guessedPlayer[0].ToString();
                                if (guessPlayer[0].ToString() == guessedPlayer[0].ToString()) //if the conference is correct
                                {
                                    nrtb4.BackColor = Color.Green;
                                }
                                crtb4.Text = guessedPlayer[1].ToString();
                                if (guessPlayer[1].ToString() == guessedPlayer[1].ToString()) //if the conference is correct
                                {
                                    crtb4.BackColor = Color.Green;
                                }
                                drtb4.Text = guessedPlayer[2].ToString();
                                if (guessPlayer[2].ToString() == guessedPlayer[2].ToString()) //if the division is correct
                                {
                                    drtb4.BackColor = Color.Green;
                                }
                                trtb4.Text = guessedPlayer[3].ToString();
                                if (guessPlayer[3].ToString() == guessedPlayer[3].ToString()) //if the team is correct
                                {
                                    trtb4.BackColor = Color.Green;
                                }
                                artb4.Text = guessedPlayer[4].ToString();
                                if (guessPlayer[4].ToString() == guessedPlayer[4].ToString()) //if the age is correct
                                {
                                    artb4.BackColor = Color.Green;
                                }
                                hrtb4.Text = guessedPlayer[5].ToString();
                                if (guessPlayer[5].ToString() == guessedPlayer[5].ToString()) //if the height is correct
                                {
                                    hrtb4.BackColor = Color.Green;
                                }
                                prtb4.Text = guessedPlayer[6].ToString();
                                if (guessPlayer[6].ToString() == guessedPlayer[6].ToString()) //if position is correct
                                {
                                    prtb4.BackColor = Color.Green;
                                }
                                jrtb4.Text = guessedPlayer[7].ToString();
                                if (guessPlayer[7].ToString() == guessedPlayer[7].ToString()) //if jersey no. is correct
                                {
                                    jrtb4.BackColor = Color.Green;
                                }
                            }

                            else if (ctr == 5) //panel 5
                            {
                                nrtb5.Text = guessedPlayer[0].ToString();
                                if (guessPlayer[0].ToString() == guessedPlayer[0].ToString()) //if the conference is correct
                                {
                                    nrtb5.BackColor = Color.Green;
                                }
                                crtb5.Text = guessedPlayer[1].ToString();
                                if (guessPlayer[1].ToString() == guessedPlayer[1].ToString()) //if the conference is correct
                                {
                                    crtb5.BackColor = Color.Green;
                                }
                                drtb5.Text = guessedPlayer[2].ToString();
                                if (guessPlayer[2].ToString() == guessedPlayer[2].ToString()) //if the division is correct
                                {
                                    drtb5.BackColor = Color.Green;
                                }
                                trtb5.Text = guessedPlayer[3].ToString();
                                if (guessPlayer[3].ToString() == guessedPlayer[3].ToString()) //if the team is correct
                                {
                                    trtb5.BackColor = Color.Green;
                                }
                                artb5.Text = guessedPlayer[4].ToString();
                                if (guessPlayer[4].ToString() == guessedPlayer[4].ToString()) //if the age is correct
                                {
                                    artb5.BackColor = Color.Green;
                                }
                                hrtb5.Text = guessedPlayer[5].ToString();
                                if (guessPlayer[5].ToString() == guessedPlayer[5].ToString()) //if the height is correct
                                {
                                    hrtb5.BackColor = Color.Green;
                                }
                                prtb5.Text = guessedPlayer[6].ToString();
                                if (guessPlayer[6].ToString() == guessedPlayer[6].ToString()) //if position is correct
                                {
                                    prtb5.BackColor = Color.Green;
                                }
                                jrtb5.Text = guessedPlayer[7].ToString();
                                if (guessPlayer[7].ToString() == guessedPlayer[7].ToString()) //if jersey no. is correct
                                {
                                    jrtb5.BackColor = Color.Green;
                                }
                            }

                            else if (ctr == 6) //panel 6
                            {
                                nrtb6.Text = guessedPlayer[0].ToString();
                                if (guessPlayer[0].ToString() == guessedPlayer[0].ToString()) //if the conference is correct
                                {
                                    nrtb6.BackColor = Color.Green;
                                }
                                crtb6.Text = guessedPlayer[1].ToString();
                                if (guessPlayer[1].ToString() == guessedPlayer[1].ToString()) //if the conference is correct
                                {
                                    crtb6.BackColor = Color.Green;
                                }
                                drtb6.Text = guessedPlayer[2].ToString();
                                if (guessPlayer[2].ToString() == guessedPlayer[2].ToString()) //if the division is correct
                                {
                                    drtb6.BackColor = Color.Green;
                                }
                                trtb6.Text = guessedPlayer[3].ToString();
                                if (guessPlayer[3].ToString() == guessedPlayer[3].ToString()) //if the team is correct
                                {
                                    trtb6.BackColor = Color.Green;
                                }
                                artb6.Text = guessedPlayer[4].ToString();
                                if (guessPlayer[4].ToString() == guessedPlayer[4].ToString()) //if the age is correct
                                {
                                    artb6.BackColor = Color.Green;
                                }
                                hrtb6.Text = guessedPlayer[5].ToString();
                                if (guessPlayer[5].ToString() == guessedPlayer[5].ToString()) //if the height is correct
                                {
                                    hrtb6.BackColor = Color.Green;
                                }
                                prtb6.Text = guessedPlayer[6].ToString();
                                if (guessPlayer[6].ToString() == guessedPlayer[6].ToString()) //if position is correct
                                {
                                    prtb6.BackColor = Color.Green;
                                }
                                jrtb6.Text = guessedPlayer[7].ToString();
                                if (guessPlayer[7].ToString() == guessedPlayer[7].ToString()) //if jersey no. is correct
                                {
                                    jrtb6.BackColor = Color.Green;
                                }
                            }

                            else if (ctr == 7) //panel 7
                            {
                                nrtb7.Text = guessedPlayer[0].ToString();
                                if (guessPlayer[0].ToString() == guessedPlayer[0].ToString()) //if the conference is correct
                                {
                                    nrtb7.BackColor = Color.Green;
                                }
                                crtb7.Text = guessedPlayer[1].ToString();
                                if (guessPlayer[1].ToString() == guessedPlayer[1].ToString()) //if the conference is correct
                                {
                                    crtb7.BackColor = Color.Green;
                                }
                                drtb7.Text = guessedPlayer[2].ToString();
                                if (guessPlayer[2].ToString() == guessedPlayer[2].ToString()) //if the division is correct
                                {
                                    drtb7.BackColor = Color.Green;
                                }
                                trtb7.Text = guessedPlayer[3].ToString();
                                if (guessPlayer[3].ToString() == guessedPlayer[3].ToString()) //if the team is correct
                                {
                                    trtb7.BackColor = Color.Green;
                                }
                                artb7.Text = guessedPlayer[4].ToString();
                                if (guessPlayer[4].ToString() == guessedPlayer[4].ToString()) //if the age is correct
                                {
                                    artb7.BackColor = Color.Green;
                                }
                                hrtb7.Text = guessedPlayer[5].ToString();
                                if (guessPlayer[5].ToString() == guessedPlayer[5].ToString()) //if the height is correct
                                {
                                    hrtb7.BackColor = Color.Green;
                                }
                                prtb7.Text = guessedPlayer[6].ToString();
                                if (guessPlayer[6].ToString() == guessedPlayer[6].ToString()) //if position is correct
                                {
                                    prtb7.BackColor = Color.Green;
                                }
                                jrtb7.Text = guessedPlayer[7].ToString();
                                if (guessPlayer[7].ToString() == guessedPlayer[7].ToString()) //if jersey no. is correct
                                {
                                    jrtb7.BackColor = Color.Green;
                                }
                            }

                            else if (ctr == 8)
                            {
                                nrtb8.Text = guessedPlayer[0].ToString();
                                if (guessPlayer[0].ToString() == guessedPlayer[0].ToString()) //if the conference is correct
                                {
                                    nrtb8.BackColor = Color.Green;
                                }
                                crtb8.Text = guessedPlayer[1].ToString();
                                if (guessPlayer[1].ToString() == guessedPlayer[1].ToString()) //if the conference is correct
                                {
                                    crtb8.BackColor = Color.Green;
                                }
                                drtb8.Text = guessedPlayer[2].ToString();
                                if (guessPlayer[2].ToString() == guessedPlayer[2].ToString()) //if the division is correct
                                {
                                    drtb8.BackColor = Color.Green;
                                }
                                trtb8.Text = guessedPlayer[3].ToString();
                                if (guessPlayer[3].ToString() == guessedPlayer[3].ToString()) //if the team is correct
                                {
                                    trtb8.BackColor = Color.Green;
                                }
                                artb8.Text = guessedPlayer[4].ToString();
                                if (guessPlayer[4].ToString() == guessedPlayer[4].ToString()) //if the age is correct
                                {
                                    artb8.BackColor = Color.Green;
                                }
                                hrtb8.Text = guessedPlayer[5].ToString();
                                if (guessPlayer[5].ToString() == guessedPlayer[5].ToString()) //if the height is correct
                                {
                                    hrtb8.BackColor = Color.Green;
                                }
                                prtb8.Text = guessedPlayer[6].ToString();
                                if (guessPlayer[6].ToString() == guessedPlayer[6].ToString()) //if position is correct
                                {
                                    prtb8.BackColor = Color.Green;
                                }
                                jrtb8.Text = guessedPlayer[7].ToString();
                                if (guessPlayer[7].ToString() == guessedPlayer[7].ToString()) //if jersey no. is correct
                                {
                                    jrtb8.BackColor = Color.Green;
                                }
                            }
                        }

                        else if (guessPlayer[0] == guessedPlayer[0]) //if the names are equal turn everything green and display message
                        {
                            if (ctr == 1) //panel 1
                            {
                                nrtb1.Text = guessedPlayer[0].ToString();
                                nrtb1.BackColor = Color.Green;
                                crtb1.Text = guessedPlayer[1].ToString();
                                crtb1.BackColor = Color.Green;
                                drtb1.Text = guessedPlayer[2].ToString();
                                drtb1.BackColor = Color.Green;
                                trtb1.Text = guessedPlayer[3].ToString();
                                trtb1.BackColor = Color.Green;
                                artb1.Text = guessedPlayer[4].ToString();
                                artb1.BackColor = Color.Green;
                                hrtb1.Text = guessedPlayer[5].ToString();
                                hrtb1.BackColor = Color.Green;
                                prtb1.Text = guessedPlayer[6].ToString();
                                prtb1.BackColor = Color.Green;
                                jrtb1.Text = guessedPlayer[7].ToString();
                                jrtb1.BackColor = Color.Green;

                                MessageBox.Show("Bravo! You did it!");
                            }

                            else if (ctr == 2) //panel 2
                            {
                                nrtb2.Text = guessedPlayer[0].ToString();
                                nrtb2.BackColor = Color.Green;
                                crtb2.Text = guessedPlayer[1].ToString();
                                crtb2.BackColor = Color.Green;
                                drtb2.Text = guessedPlayer[2].ToString();
                                drtb2.BackColor = Color.Green;
                                trtb2.Text = guessedPlayer[3].ToString();
                                trtb2.BackColor = Color.Green;
                                artb2.Text = guessedPlayer[4].ToString();
                                artb2.BackColor = Color.Green;
                                hrtb2.Text = guessedPlayer[5].ToString();
                                hrtb2.BackColor = Color.Green;
                                prtb2.Text = guessedPlayer[6].ToString();
                                prtb2.BackColor = Color.Green;
                                jrtb2.Text = guessedPlayer[7].ToString();
                                jrtb2.BackColor = Color.Green;

                                MessageBox.Show("Bravo! You did it!");

                            }

                            else if (ctr == 3) //panel 3
                            {
                                nrtb3.Text = guessedPlayer[0].ToString();
                                nrtb3.BackColor = Color.Green;
                                crtb3.Text = guessedPlayer[1].ToString();
                                crtb3.BackColor = Color.Green;
                                drtb3.Text = guessedPlayer[2].ToString();
                                drtb3.BackColor = Color.Green;
                                trtb3.Text = guessedPlayer[3].ToString();
                                trtb3.BackColor = Color.Green;
                                artb3.Text = guessedPlayer[4].ToString();
                                artb3.BackColor = Color.Green;
                                hrtb3.Text = guessedPlayer[5].ToString();
                                hrtb3.BackColor = Color.Green;
                                prtb3.Text = guessedPlayer[6].ToString();
                                prtb3.BackColor = Color.Green;
                                jrtb3.Text = guessedPlayer[7].ToString();
                                jrtb3.BackColor = Color.Green;

                                MessageBox.Show("Bravo! You did it!");

                            }

                            else if (ctr == 4) //panel 4
                            {
                                nrtb4.Text = guessedPlayer[0].ToString();
                                nrtb4.BackColor = Color.Green;
                                crtb4.Text = guessedPlayer[1].ToString();
                                crtb4.BackColor = Color.Green;
                                drtb4.Text = guessedPlayer[2].ToString();
                                drtb4.BackColor = Color.Green;
                                trtb4.Text = guessedPlayer[3].ToString();
                                trtb4.BackColor = Color.Green;
                                artb4.Text = guessedPlayer[4].ToString();
                                artb4.BackColor = Color.Green;
                                hrtb4.Text = guessedPlayer[5].ToString();
                                hrtb4.BackColor = Color.Green;
                                prtb4.Text = guessedPlayer[6].ToString();
                                prtb4.BackColor = Color.Green;
                                jrtb4.Text = guessedPlayer[7].ToString();
                                jrtb4.BackColor = Color.Green;

                                MessageBox.Show("Bravo! You did it!");

                            }

                            else if (ctr == 5) //panel 5
                            {
                                nrtb5.Text = guessedPlayer[0].ToString();
                                nrtb5.BackColor = Color.Green;
                                crtb5.Text = guessedPlayer[1].ToString();
                                crtb5.BackColor = Color.Green;
                                drtb5.Text = guessedPlayer[2].ToString();
                                drtb5.BackColor = Color.Green;
                                trtb5.Text = guessedPlayer[3].ToString();
                                trtb5.BackColor = Color.Green;
                                artb5.Text = guessedPlayer[4].ToString();
                                artb5.BackColor = Color.Green;
                                hrtb5.Text = guessedPlayer[5].ToString();
                                hrtb5.BackColor = Color.Green;
                                prtb5.Text = guessedPlayer[6].ToString();
                                prtb5.BackColor = Color.Green;
                                jrtb5.Text = guessedPlayer[7].ToString();
                                jrtb5.BackColor = Color.Green;

                                MessageBox.Show("Bravo! You did it!");

                            }

                            else if (ctr == 6) //panel 6
                            {
                                nrtb6.Text = guessedPlayer[0].ToString();
                                nrtb6.BackColor = Color.Green;
                                crtb6.Text = guessedPlayer[1].ToString();
                                crtb6.BackColor = Color.Green;
                                drtb6.Text = guessedPlayer[2].ToString();
                                drtb6.BackColor = Color.Green;
                                trtb6.Text = guessedPlayer[3].ToString();
                                trtb6.BackColor = Color.Green;
                                artb6.Text = guessedPlayer[4].ToString();
                                artb6.BackColor = Color.Green;
                                hrtb6.Text = guessedPlayer[5].ToString();
                                hrtb6.BackColor = Color.Green;
                                prtb6.Text = guessedPlayer[6].ToString();
                                prtb6.BackColor = Color.Green;
                                jrtb6.Text = guessedPlayer[7].ToString();
                                jrtb6.BackColor = Color.Green;

                                MessageBox.Show("Bravo! You did it!");

                            }

                            else if (ctr == 7) //panel 7
                            {
                                nrtb7.Text = guessedPlayer[0].ToString();
                                nrtb7.BackColor = Color.Green;
                                crtb7.Text = guessedPlayer[1].ToString();
                                crtb7.BackColor = Color.Green;
                                drtb7.Text = guessedPlayer[2].ToString();
                                drtb7.BackColor = Color.Green;
                                trtb7.Text = guessedPlayer[3].ToString();
                                trtb7.BackColor = Color.Green;
                                artb7.Text = guessedPlayer[4].ToString();
                                artb7.BackColor = Color.Green;
                                hrtb7.Text = guessedPlayer[5].ToString();
                                hrtb7.BackColor = Color.Green;
                                prtb7.Text = guessedPlayer[6].ToString();
                                prtb7.BackColor = Color.Green;
                                jrtb7.Text = guessedPlayer[7].ToString();
                                jrtb7.BackColor = Color.Green;

                                MessageBox.Show("Bravo! You did it!");

                            }

                            else if (ctr == 8)
                            {
                                nrtb8.Text = guessedPlayer[0].ToString();
                                nrtb8.BackColor = Color.Green;
                                crtb8.Text = guessedPlayer[1].ToString();
                                crtb8.BackColor = Color.Green;
                                drtb8.Text = guessedPlayer[2].ToString();
                                drtb8.BackColor = Color.Green;
                                trtb8.Text = guessedPlayer[3].ToString();
                                trtb8.BackColor = Color.Green;
                                artb8.Text = guessedPlayer[4].ToString();
                                artb8.BackColor = Color.Green;
                                hrtb8.Text = guessedPlayer[5].ToString();
                                hrtb8.BackColor = Color.Green;
                                prtb8.Text = guessedPlayer[6].ToString();
                                prtb8.BackColor = Color.Green;
                                jrtb8.Text = guessedPlayer[7].ToString();
                                jrtb8.BackColor = Color.Green;

                                MessageBox.Show("Bravo! You did it!");
                                MessageBox.Show(string.Join(Environment.NewLine, gameData));
                            }
                        }
                        ctr++;
                        j++;
                    }
                }

                else
                {
                    MessageBox.Show("Name Not Found"); //confirmation
                }

                excel.Quit();
            }

        }

        private void loginButton_Click(object sender, EventArgs e) //when login button is clicked
        {
            if (null == loginForm || loginForm.IsDisposed)
            {
                loginForm = new LoginForm();
            } //check if login form exists

            loginForm.Enabled = true; //account form will open in modify mode
            loginForm.Show(); //open the account form
        }
    }
}
