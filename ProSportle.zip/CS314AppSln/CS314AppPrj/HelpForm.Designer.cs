﻿namespace CS314AppPrj
{
    partial class HelpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HelpForm));
            this.helpLabel = new System.Windows.Forms.Label();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.instructionsPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // helpLabel
            // 
            this.helpLabel.AutoSize = true;
            this.helpLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.helpLabel.ForeColor = System.Drawing.Color.Black;
            this.helpLabel.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.helpLabel.Location = new System.Drawing.Point(237, 9);
            this.helpLabel.Name = "helpLabel";
            this.helpLabel.Size = new System.Drawing.Size(276, 52);
            this.helpLabel.TabIndex = 1;
            this.helpLabel.Text = "How-To-Play";
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // instructionsPictureBox
            // 
            this.instructionsPictureBox.ErrorImage = ((System.Drawing.Image)(resources.GetObject("instructionsPictureBox.ErrorImage")));
            this.instructionsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("instructionsPictureBox.Image")));
            this.instructionsPictureBox.ImageLocation = "C:\\Users\\arian\\OneDrive\\Desktop\\COLLEGE\\Undergrad\\AAMU\\CLASSES\\Spring 2023\\CS 403" +
    " - Senior Problems";
            this.instructionsPictureBox.InitialImage = null;
            this.instructionsPictureBox.Location = new System.Drawing.Point(67, 64);
            this.instructionsPictureBox.Name = "instructionsPictureBox";
            this.instructionsPictureBox.Size = new System.Drawing.Size(613, 437);
            this.instructionsPictureBox.TabIndex = 2;
            this.instructionsPictureBox.TabStop = false;
            // 
            // HelpForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(775, 519);
            this.Controls.Add(this.instructionsPictureBox);
            this.Controls.Add(this.helpLabel);
            this.MaximumSize = new System.Drawing.Size(900, 690);
            this.Name = "HelpForm";
            this.Load += new System.EventHandler(this.HelpForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.instructionsPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label helpLabel;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.PictureBox instructionsPictureBox;
    }
}