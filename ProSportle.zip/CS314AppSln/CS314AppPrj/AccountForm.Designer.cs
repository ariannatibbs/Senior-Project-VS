﻿namespace CS314AppPrj
{
    partial class AccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.accountPanel = new System.Windows.Forms.Panel();
            this.restrictionsLabel = new System.Windows.Forms.Label();
            this.createButton = new System.Windows.Forms.Button();
            this.contactInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.cellTextBox = new System.Windows.Forms.TextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.cellLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.lnameTextBox = new System.Windows.Forms.TextBox();
            this.usernameTextBox = new System.Windows.Forms.TextBox();
            this.fnameTextBox = new System.Windows.Forms.TextBox();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.usernameLabel = new System.Windows.Forms.Label();
            this.accountTitleLabel = new System.Windows.Forms.Label();
            this.accountPanel.SuspendLayout();
            this.contactInfoGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // accountPanel
            // 
            this.accountPanel.BackColor = System.Drawing.SystemColors.Control;
            this.accountPanel.Controls.Add(this.restrictionsLabel);
            this.accountPanel.Controls.Add(this.createButton);
            this.accountPanel.Controls.Add(this.contactInfoGroupBox);
            this.accountPanel.Controls.Add(this.lnameTextBox);
            this.accountPanel.Controls.Add(this.usernameTextBox);
            this.accountPanel.Controls.Add(this.fnameTextBox);
            this.accountPanel.Controls.Add(this.passwordTextBox);
            this.accountPanel.Controls.Add(this.lastNameLabel);
            this.accountPanel.Controls.Add(this.firstNameLabel);
            this.accountPanel.Controls.Add(this.passwordLabel);
            this.accountPanel.Controls.Add(this.usernameLabel);
            this.accountPanel.Location = new System.Drawing.Point(12, 67);
            this.accountPanel.Name = "accountPanel";
            this.accountPanel.Size = new System.Drawing.Size(846, 334);
            this.accountPanel.TabIndex = 2;
            // 
            // restrictionsLabel
            // 
            this.restrictionsLabel.AutoSize = true;
            this.restrictionsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.restrictionsLabel.Location = new System.Drawing.Point(23, 285);
            this.restrictionsLabel.Name = "restrictionsLabel";
            this.restrictionsLabel.Size = new System.Drawing.Size(488, 45);
            this.restrictionsLabel.TabIndex = 11;
            this.restrictionsLabel.Text = "Note: Username must be at least five characters long. No special characters.\r\n   " +
    "       Password must be at least eight characters long. Must contain at least on" +
    "e number.\r\n\r\n";
            // 
            // createButton
            // 
            this.createButton.Location = new System.Drawing.Point(712, 141);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(95, 44);
            this.createButton.TabIndex = 10;
            this.createButton.Text = "Create";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            // 
            // contactInfoGroupBox
            // 
            this.contactInfoGroupBox.Controls.Add(this.cellTextBox);
            this.contactInfoGroupBox.Controls.Add(this.emailTextBox);
            this.contactInfoGroupBox.Controls.Add(this.cellLabel);
            this.contactInfoGroupBox.Controls.Add(this.emailLabel);
            this.contactInfoGroupBox.Location = new System.Drawing.Point(26, 112);
            this.contactInfoGroupBox.Name = "contactInfoGroupBox";
            this.contactInfoGroupBox.Size = new System.Drawing.Size(610, 124);
            this.contactInfoGroupBox.TabIndex = 9;
            this.contactInfoGroupBox.TabStop = false;
            this.contactInfoGroupBox.Text = "Contact Info";
            // 
            // cellTextBox
            // 
            this.cellTextBox.Location = new System.Drawing.Point(167, 73);
            this.cellTextBox.Name = "cellTextBox";
            this.cellTextBox.Size = new System.Drawing.Size(250, 26);
            this.cellTextBox.TabIndex = 3;
            // 
            // emailTextBox
            // 
            this.emailTextBox.Location = new System.Drawing.Point(167, 32);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(443, 26);
            this.emailTextBox.TabIndex = 2;
            // 
            // cellLabel
            // 
            this.cellLabel.AutoSize = true;
            this.cellLabel.Location = new System.Drawing.Point(59, 76);
            this.cellLabel.Name = "cellLabel";
            this.cellLabel.Size = new System.Drawing.Size(112, 20);
            this.cellLabel.TabIndex = 1;
            this.cellLabel.Text = "Cell (Optional):";
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(46, 32);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(125, 20);
            this.emailLabel.TabIndex = 0;
            this.emailLabel.Text = "Email (Optional):";
            // 
            // lnameTextBox
            // 
            this.lnameTextBox.Location = new System.Drawing.Point(118, 53);
            this.lnameTextBox.Name = "lnameTextBox";
            this.lnameTextBox.Size = new System.Drawing.Size(270, 26);
            this.lnameTextBox.TabIndex = 7;
            // 
            // usernameTextBox
            // 
            this.usernameTextBox.Location = new System.Drawing.Point(525, 14);
            this.usernameTextBox.Name = "usernameTextBox";
            this.usernameTextBox.Size = new System.Drawing.Size(270, 26);
            this.usernameTextBox.TabIndex = 4;
            // 
            // fnameTextBox
            // 
            this.fnameTextBox.Location = new System.Drawing.Point(118, 14);
            this.fnameTextBox.Name = "fnameTextBox";
            this.fnameTextBox.Size = new System.Drawing.Size(270, 26);
            this.fnameTextBox.TabIndex = 6;
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Location = new System.Drawing.Point(525, 53);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(270, 26);
            this.passwordTextBox.TabIndex = 5;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(22, 53);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(90, 20);
            this.lastNameLabel.TabIndex = 3;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(22, 20);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(90, 20);
            this.firstNameLabel.TabIndex = 2;
            this.firstNameLabel.Text = "First Name:";
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Location = new System.Drawing.Point(437, 53);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(82, 20);
            this.passwordLabel.TabIndex = 1;
            this.passwordLabel.Text = "Password:";
            // 
            // usernameLabel
            // 
            this.usernameLabel.AutoSize = true;
            this.usernameLabel.Location = new System.Drawing.Point(432, 20);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(87, 20);
            this.usernameLabel.TabIndex = 0;
            this.usernameLabel.Text = "Username:";
            // 
            // accountTitleLabel
            // 
            this.accountTitleLabel.AutoSize = true;
            this.accountTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.accountTitleLabel.Location = new System.Drawing.Point(272, 9);
            this.accountTitleLabel.Name = "accountTitleLabel";
            this.accountTitleLabel.Size = new System.Drawing.Size(342, 37);
            this.accountTitleLabel.TabIndex = 3;
            this.accountTitleLabel.Text = "Create A New Account";
            // 
            // AccountForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 404);
            this.Controls.Add(this.accountTitleLabel);
            this.Controls.Add(this.accountPanel);
            this.Name = "AccountForm";
            this.Text = "Account";
            this.accountPanel.ResumeLayout(false);
            this.accountPanel.PerformLayout();
            this.contactInfoGroupBox.ResumeLayout(false);
            this.contactInfoGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel accountPanel;
        private System.Windows.Forms.GroupBox contactInfoGroupBox;
        private System.Windows.Forms.TextBox cellTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.Label cellLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.TextBox lnameTextBox;
        private System.Windows.Forms.TextBox fnameTextBox;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.TextBox usernameTextBox;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.Label usernameLabel;
        private System.Windows.Forms.Label accountTitleLabel;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.Label restrictionsLabel;
    }
}