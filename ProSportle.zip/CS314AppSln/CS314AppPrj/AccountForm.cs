﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS314AppPrj
{
    public partial class AccountForm : Form
    {
        //variables
        public string fname;
        public string lname;
        public string email;
        public string cell;
        public static string username;
        public static string password;
        private bool fnamesc; //variable to store bool of special character or not
        private bool lnamesc;
      
        public AccountForm()
        {
            InitializeComponent();
        }

        private void createButton_Click(object sender, EventArgs e)
        {

            fname = fnameTextBox.Text;
            lname = lnameTextBox.Text;
            email = emailTextBox.Text;
            username = usernameTextBox.Text;
            password = passwordTextBox.Text;
            cell = cellTextBox.Text;

            //codes to check if fname or lname contain special character
            foreach (var c in fname)
            {
                if (!char.IsLetterOrDigit(c))
                {
                    fnamesc = true;
                }
                else
                {
                    fnamesc = false;
                }
            }

            foreach (var c in lname)
            {
                if (!char.IsLetterOrDigit(c))
                {
                    lnamesc = true;
                }
                else
                {
                    lnamesc = false;
                }
            }


            //if any box other than cell# and email are left empty
            if (fname == null || lname == null ||  username == null || password == null) 
            {
                MessageBox.Show("Invalid Credentials. Cannot leave boxes blank.");
            }

            //if first or last name contains numbers or special characters
            else if (fname.Any(char.IsDigit) || lname.Any(char.IsDigit) || fnamesc == true || lnamesc == true)
            {
                MessageBox.Show("Invalid Credentials. Name cannot contain numbers or special characters.");
                fname = null; //empty variable
                lname = null; //empty variable
            }

            //if cell phone number is too long
            else if (cell.Length != 10)
            {
                MessageBox.Show("Invalid Credentials. Cell numbers must be ten digits long.");
                cell = null; //empty variable
            }

            //is username is not long enough
            else if (username.Length < 5)
            {
                MessageBox.Show("Invalid Credentials. Username must be at least five characters long.");
                username = null; //empty variable
            }

            //if password is too short or does not contain a number
            else if (password.Length < 8 || password.Any(char.IsDigit) == false)
            {
                MessageBox.Show("Invalid Credentials. Password must be at least eight characters and include a number.");
                password = null; //empty variable
            }

            else
            {
                MessageBox.Show("Account saved.");
                this.Close();
            }

            LoginForm loginForm = new LoginForm();
            loginForm.Show();

            
            
      
        }
    }
}
