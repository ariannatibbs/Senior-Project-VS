﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS314AppPrj
{
    public partial class LoginForm : Form
    {
        //declare child forms for this form
        MainScreen homeForm;
        AccountForm accountForm;

        public LoginForm()
        {
            InitializeComponent();

            //change the text for the form
            //usernameTextBox.Text == AccountForm.username
        }

        private void loginButton_Click(object sender, EventArgs e) //login button code
        {
            //decrypt password
            //string decrypted_pass = AccountForm.decrypt(AccountForm.encryptedPass, 26 - AccountForm.key);
            //MessageBox.Show(decrypted_pass);

            //compare username and password values
            if (usernameTextBox.Text == AccountForm.username && passwordTextBox.Text == AccountForm.password) //if the user enters the right credentials
            {
                MessageBox.Show("Login Successful."); 
                this.Close();               
            }

            else
            {
                MessageBox.Show("Incorrect username or password."); //tell the user their credentials are incorrect
            }
        }

        private void cancelButton_Click(object sender, EventArgs e) //cancel button code
        {
            this.Close(); //close form
        }

        private void new_account_linkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) //new account button code
        {
            if (null == accountForm || accountForm.IsDisposed)
            {
                accountForm = new AccountForm();
            } //check if account form exists

            accountForm.Enabled = true; //account form will open in modify mode
            accountForm.Show(); //open the account form
            this.Close();
        }
    }
}
