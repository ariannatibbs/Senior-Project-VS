﻿namespace CS314AppPrj
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.helpButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.guessBox = new System.Windows.Forms.ComboBox();
            this.picturePanel = new System.Windows.Forms.Panel();
            this.jerseyLabel = new System.Windows.Forms.Label();
            this.positionlabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.teamLabel = new System.Windows.Forms.Label();
            this.divisionLabel = new System.Windows.Forms.Label();
            this.conferenceLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.startButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.jrtb1 = new System.Windows.Forms.RichTextBox();
            this.crtb1 = new System.Windows.Forms.RichTextBox();
            this.drtb1 = new System.Windows.Forms.RichTextBox();
            this.prtb1 = new System.Windows.Forms.RichTextBox();
            this.nrtb1 = new System.Windows.Forms.RichTextBox();
            this.hrtb1 = new System.Windows.Forms.RichTextBox();
            this.artb1 = new System.Windows.Forms.RichTextBox();
            this.trtb1 = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.jrtb2 = new System.Windows.Forms.RichTextBox();
            this.crtb2 = new System.Windows.Forms.RichTextBox();
            this.drtb2 = new System.Windows.Forms.RichTextBox();
            this.prtb2 = new System.Windows.Forms.RichTextBox();
            this.nrtb2 = new System.Windows.Forms.RichTextBox();
            this.hrtb2 = new System.Windows.Forms.RichTextBox();
            this.artb2 = new System.Windows.Forms.RichTextBox();
            this.trtb2 = new System.Windows.Forms.RichTextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.jrtb3 = new System.Windows.Forms.RichTextBox();
            this.crtb3 = new System.Windows.Forms.RichTextBox();
            this.drtb3 = new System.Windows.Forms.RichTextBox();
            this.prtb3 = new System.Windows.Forms.RichTextBox();
            this.nrtb3 = new System.Windows.Forms.RichTextBox();
            this.hrtb3 = new System.Windows.Forms.RichTextBox();
            this.artb3 = new System.Windows.Forms.RichTextBox();
            this.trtb3 = new System.Windows.Forms.RichTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.jrtb4 = new System.Windows.Forms.RichTextBox();
            this.crtb4 = new System.Windows.Forms.RichTextBox();
            this.drtb4 = new System.Windows.Forms.RichTextBox();
            this.prtb4 = new System.Windows.Forms.RichTextBox();
            this.nrtb4 = new System.Windows.Forms.RichTextBox();
            this.hrtb4 = new System.Windows.Forms.RichTextBox();
            this.artb4 = new System.Windows.Forms.RichTextBox();
            this.trtb4 = new System.Windows.Forms.RichTextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.jrtb5 = new System.Windows.Forms.RichTextBox();
            this.crtb5 = new System.Windows.Forms.RichTextBox();
            this.drtb5 = new System.Windows.Forms.RichTextBox();
            this.prtb5 = new System.Windows.Forms.RichTextBox();
            this.nrtb5 = new System.Windows.Forms.RichTextBox();
            this.hrtb5 = new System.Windows.Forms.RichTextBox();
            this.artb5 = new System.Windows.Forms.RichTextBox();
            this.trtb5 = new System.Windows.Forms.RichTextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.jrtb6 = new System.Windows.Forms.RichTextBox();
            this.crtb6 = new System.Windows.Forms.RichTextBox();
            this.drtb6 = new System.Windows.Forms.RichTextBox();
            this.prtb6 = new System.Windows.Forms.RichTextBox();
            this.nrtb6 = new System.Windows.Forms.RichTextBox();
            this.hrtb6 = new System.Windows.Forms.RichTextBox();
            this.artb6 = new System.Windows.Forms.RichTextBox();
            this.trtb6 = new System.Windows.Forms.RichTextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.jrtb7 = new System.Windows.Forms.RichTextBox();
            this.crtb7 = new System.Windows.Forms.RichTextBox();
            this.drtb7 = new System.Windows.Forms.RichTextBox();
            this.prtb7 = new System.Windows.Forms.RichTextBox();
            this.nrtb7 = new System.Windows.Forms.RichTextBox();
            this.hrtb7 = new System.Windows.Forms.RichTextBox();
            this.artb7 = new System.Windows.Forms.RichTextBox();
            this.trtb7 = new System.Windows.Forms.RichTextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.jrtb8 = new System.Windows.Forms.RichTextBox();
            this.crtb8 = new System.Windows.Forms.RichTextBox();
            this.drtb8 = new System.Windows.Forms.RichTextBox();
            this.prtb8 = new System.Windows.Forms.RichTextBox();
            this.nrtb8 = new System.Windows.Forms.RichTextBox();
            this.hrtb8 = new System.Windows.Forms.RichTextBox();
            this.artb8 = new System.Windows.Forms.RichTextBox();
            this.trtb8 = new System.Windows.Forms.RichTextBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.enterButton = new System.Windows.Forms.Button();
            this.loginButton = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.picturePanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // helpButton
            // 
            this.helpButton.Location = new System.Drawing.Point(1817, 12);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(37, 36);
            this.helpButton.TabIndex = 1;
            this.helpButton.Text = "?";
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(1718, 12);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(65, 36);
            this.resetButton.TabIndex = 4;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // guessBox
            // 
            this.guessBox.AllowDrop = true;
            this.guessBox.DropDownHeight = 200;
            this.guessBox.DropDownWidth = 800;
            this.guessBox.FormattingEnabled = true;
            this.guessBox.IntegralHeight = false;
            this.guessBox.Location = new System.Drawing.Point(16, 1008);
            this.guessBox.MaxDropDownItems = 50;
            this.guessBox.Name = "guessBox";
            this.guessBox.Size = new System.Drawing.Size(818, 28);
            this.guessBox.TabIndex = 5;
            this.guessBox.Text = "Insert Name Here...";
            // 
            // picturePanel
            // 
            this.picturePanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picturePanel.Controls.Add(this.jerseyLabel);
            this.picturePanel.Controls.Add(this.positionlabel);
            this.picturePanel.Controls.Add(this.heightLabel);
            this.picturePanel.Controls.Add(this.ageLabel);
            this.picturePanel.Controls.Add(this.teamLabel);
            this.picturePanel.Controls.Add(this.divisionLabel);
            this.picturePanel.Controls.Add(this.conferenceLabel);
            this.picturePanel.Controls.Add(this.nameLabel);
            this.picturePanel.Location = new System.Drawing.Point(16, 19);
            this.picturePanel.Name = "picturePanel";
            this.picturePanel.Size = new System.Drawing.Size(915, 30);
            this.picturePanel.TabIndex = 15;
            // 
            // jerseyLabel
            // 
            this.jerseyLabel.AutoSize = true;
            this.jerseyLabel.Location = new System.Drawing.Point(831, 4);
            this.jerseyLabel.Name = "jerseyLabel";
            this.jerseyLabel.Size = new System.Drawing.Size(68, 20);
            this.jerseyLabel.TabIndex = 18;
            this.jerseyLabel.Text = "Jersey #";
            // 
            // positionlabel
            // 
            this.positionlabel.AutoSize = true;
            this.positionlabel.Location = new System.Drawing.Point(719, 4);
            this.positionlabel.Name = "positionlabel";
            this.positionlabel.Size = new System.Drawing.Size(65, 20);
            this.positionlabel.TabIndex = 18;
            this.positionlabel.Text = "Position";
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Location = new System.Drawing.Point(609, 4);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(56, 20);
            this.heightLabel.TabIndex = 18;
            this.heightLabel.Text = "Height";
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(501, 4);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(38, 20);
            this.ageLabel.TabIndex = 18;
            this.ageLabel.Text = "Age";
            // 
            // teamLabel
            // 
            this.teamLabel.AutoSize = true;
            this.teamLabel.Location = new System.Drawing.Point(380, 4);
            this.teamLabel.Name = "teamLabel";
            this.teamLabel.Size = new System.Drawing.Size(49, 20);
            this.teamLabel.TabIndex = 18;
            this.teamLabel.Text = "Team";
            // 
            // divisionLabel
            // 
            this.divisionLabel.AutoSize = true;
            this.divisionLabel.Location = new System.Drawing.Point(257, 4);
            this.divisionLabel.Name = "divisionLabel";
            this.divisionLabel.Size = new System.Drawing.Size(63, 20);
            this.divisionLabel.TabIndex = 18;
            this.divisionLabel.Text = "Division";
            // 
            // conferenceLabel
            // 
            this.conferenceLabel.AutoSize = true;
            this.conferenceLabel.Location = new System.Drawing.Point(123, 4);
            this.conferenceLabel.Name = "conferenceLabel";
            this.conferenceLabel.Size = new System.Drawing.Size(92, 20);
            this.conferenceLabel.TabIndex = 7;
            this.conferenceLabel.Text = "Conference";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(37, 4);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(51, 20);
            this.nameLabel.TabIndex = 6;
            this.nameLabel.Text = "Name";
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(1582, 12);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(102, 36);
            this.startButton.TabIndex = 16;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.jrtb1);
            this.panel1.Controls.Add(this.crtb1);
            this.panel1.Controls.Add(this.drtb1);
            this.panel1.Controls.Add(this.prtb1);
            this.panel1.Controls.Add(this.nrtb1);
            this.panel1.Controls.Add(this.hrtb1);
            this.panel1.Controls.Add(this.artb1);
            this.panel1.Controls.Add(this.trtb1);
            this.panel1.Location = new System.Drawing.Point(16, 55);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(925, 110);
            this.panel1.TabIndex = 17;
            // 
            // jrtb1
            // 
            this.jrtb1.Location = new System.Drawing.Point(823, 11);
            this.jrtb1.Name = "jrtb1";
            this.jrtb1.ReadOnly = true;
            this.jrtb1.Size = new System.Drawing.Size(90, 90);
            this.jrtb1.TabIndex = 18;
            this.jrtb1.Text = "";
            // 
            // crtb1
            // 
            this.crtb1.Location = new System.Drawing.Point(127, 11);
            this.crtb1.Name = "crtb1";
            this.crtb1.ReadOnly = true;
            this.crtb1.Size = new System.Drawing.Size(90, 90);
            this.crtb1.TabIndex = 6;
            this.crtb1.Text = "";
            // 
            // drtb1
            // 
            this.drtb1.Location = new System.Drawing.Point(243, 11);
            this.drtb1.Name = "drtb1";
            this.drtb1.ReadOnly = true;
            this.drtb1.Size = new System.Drawing.Size(90, 90);
            this.drtb1.TabIndex = 1;
            this.drtb1.Text = "";
            // 
            // prtb1
            // 
            this.prtb1.Location = new System.Drawing.Point(707, 11);
            this.prtb1.Name = "prtb1";
            this.prtb1.ReadOnly = true;
            this.prtb1.Size = new System.Drawing.Size(90, 90);
            this.prtb1.TabIndex = 2;
            this.prtb1.Text = "";
            // 
            // nrtb1
            // 
            this.nrtb1.BackColor = System.Drawing.Color.White;
            this.nrtb1.Location = new System.Drawing.Point(11, 11);
            this.nrtb1.Name = "nrtb1";
            this.nrtb1.ReadOnly = true;
            this.nrtb1.Size = new System.Drawing.Size(90, 90);
            this.nrtb1.TabIndex = 0;
            this.nrtb1.Text = "";
            // 
            // hrtb1
            // 
            this.hrtb1.Location = new System.Drawing.Point(591, 11);
            this.hrtb1.Name = "hrtb1";
            this.hrtb1.ReadOnly = true;
            this.hrtb1.Size = new System.Drawing.Size(90, 90);
            this.hrtb1.TabIndex = 4;
            this.hrtb1.Text = "";
            // 
            // artb1
            // 
            this.artb1.Location = new System.Drawing.Point(475, 11);
            this.artb1.Name = "artb1";
            this.artb1.ReadOnly = true;
            this.artb1.Size = new System.Drawing.Size(90, 90);
            this.artb1.TabIndex = 3;
            this.artb1.Text = "";
            // 
            // trtb1
            // 
            this.trtb1.Location = new System.Drawing.Point(359, 11);
            this.trtb1.Name = "trtb1";
            this.trtb1.ReadOnly = true;
            this.trtb1.Size = new System.Drawing.Size(90, 90);
            this.trtb1.TabIndex = 5;
            this.trtb1.Text = "";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.jrtb2);
            this.panel2.Controls.Add(this.crtb2);
            this.panel2.Controls.Add(this.drtb2);
            this.panel2.Controls.Add(this.prtb2);
            this.panel2.Controls.Add(this.nrtb2);
            this.panel2.Controls.Add(this.hrtb2);
            this.panel2.Controls.Add(this.artb2);
            this.panel2.Controls.Add(this.trtb2);
            this.panel2.Location = new System.Drawing.Point(16, 171);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(925, 110);
            this.panel2.TabIndex = 18;
            // 
            // jrtb2
            // 
            this.jrtb2.Location = new System.Drawing.Point(823, 11);
            this.jrtb2.Name = "jrtb2";
            this.jrtb2.ReadOnly = true;
            this.jrtb2.Size = new System.Drawing.Size(90, 90);
            this.jrtb2.TabIndex = 18;
            this.jrtb2.Text = "";
            // 
            // crtb2
            // 
            this.crtb2.Location = new System.Drawing.Point(127, 11);
            this.crtb2.Name = "crtb2";
            this.crtb2.ReadOnly = true;
            this.crtb2.Size = new System.Drawing.Size(90, 90);
            this.crtb2.TabIndex = 6;
            this.crtb2.Text = "";
            // 
            // drtb2
            // 
            this.drtb2.Location = new System.Drawing.Point(243, 11);
            this.drtb2.Name = "drtb2";
            this.drtb2.ReadOnly = true;
            this.drtb2.Size = new System.Drawing.Size(90, 90);
            this.drtb2.TabIndex = 1;
            this.drtb2.Text = "";
            // 
            // prtb2
            // 
            this.prtb2.Location = new System.Drawing.Point(707, 11);
            this.prtb2.Name = "prtb2";
            this.prtb2.ReadOnly = true;
            this.prtb2.Size = new System.Drawing.Size(90, 90);
            this.prtb2.TabIndex = 2;
            this.prtb2.Text = "";
            // 
            // nrtb2
            // 
            this.nrtb2.Location = new System.Drawing.Point(11, 11);
            this.nrtb2.Name = "nrtb2";
            this.nrtb2.ReadOnly = true;
            this.nrtb2.Size = new System.Drawing.Size(90, 90);
            this.nrtb2.TabIndex = 0;
            this.nrtb2.Text = "";
            // 
            // hrtb2
            // 
            this.hrtb2.Location = new System.Drawing.Point(591, 11);
            this.hrtb2.Name = "hrtb2";
            this.hrtb2.ReadOnly = true;
            this.hrtb2.Size = new System.Drawing.Size(90, 90);
            this.hrtb2.TabIndex = 4;
            this.hrtb2.Text = "";
            // 
            // artb2
            // 
            this.artb2.Location = new System.Drawing.Point(475, 11);
            this.artb2.Name = "artb2";
            this.artb2.ReadOnly = true;
            this.artb2.Size = new System.Drawing.Size(90, 90);
            this.artb2.TabIndex = 3;
            this.artb2.Text = "";
            // 
            // trtb2
            // 
            this.trtb2.Location = new System.Drawing.Point(359, 11);
            this.trtb2.Name = "trtb2";
            this.trtb2.ReadOnly = true;
            this.trtb2.Size = new System.Drawing.Size(90, 90);
            this.trtb2.TabIndex = 5;
            this.trtb2.Text = "";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.jrtb3);
            this.panel3.Controls.Add(this.crtb3);
            this.panel3.Controls.Add(this.drtb3);
            this.panel3.Controls.Add(this.prtb3);
            this.panel3.Controls.Add(this.nrtb3);
            this.panel3.Controls.Add(this.hrtb3);
            this.panel3.Controls.Add(this.artb3);
            this.panel3.Controls.Add(this.trtb3);
            this.panel3.Location = new System.Drawing.Point(16, 287);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(925, 110);
            this.panel3.TabIndex = 19;
            // 
            // jrtb3
            // 
            this.jrtb3.Location = new System.Drawing.Point(823, 11);
            this.jrtb3.Name = "jrtb3";
            this.jrtb3.ReadOnly = true;
            this.jrtb3.Size = new System.Drawing.Size(90, 90);
            this.jrtb3.TabIndex = 18;
            this.jrtb3.Text = "";
            // 
            // crtb3
            // 
            this.crtb3.Location = new System.Drawing.Point(127, 11);
            this.crtb3.Name = "crtb3";
            this.crtb3.ReadOnly = true;
            this.crtb3.Size = new System.Drawing.Size(90, 90);
            this.crtb3.TabIndex = 6;
            this.crtb3.Text = "";
            // 
            // drtb3
            // 
            this.drtb3.Location = new System.Drawing.Point(243, 11);
            this.drtb3.Name = "drtb3";
            this.drtb3.ReadOnly = true;
            this.drtb3.Size = new System.Drawing.Size(90, 90);
            this.drtb3.TabIndex = 1;
            this.drtb3.Text = "";
            // 
            // prtb3
            // 
            this.prtb3.Location = new System.Drawing.Point(707, 11);
            this.prtb3.Name = "prtb3";
            this.prtb3.ReadOnly = true;
            this.prtb3.Size = new System.Drawing.Size(90, 90);
            this.prtb3.TabIndex = 2;
            this.prtb3.Text = "";
            // 
            // nrtb3
            // 
            this.nrtb3.Location = new System.Drawing.Point(11, 11);
            this.nrtb3.Name = "nrtb3";
            this.nrtb3.ReadOnly = true;
            this.nrtb3.Size = new System.Drawing.Size(90, 90);
            this.nrtb3.TabIndex = 0;
            this.nrtb3.Text = "";
            // 
            // hrtb3
            // 
            this.hrtb3.Location = new System.Drawing.Point(591, 11);
            this.hrtb3.Name = "hrtb3";
            this.hrtb3.ReadOnly = true;
            this.hrtb3.Size = new System.Drawing.Size(90, 90);
            this.hrtb3.TabIndex = 4;
            this.hrtb3.Text = "";
            // 
            // artb3
            // 
            this.artb3.Location = new System.Drawing.Point(475, 11);
            this.artb3.Name = "artb3";
            this.artb3.ReadOnly = true;
            this.artb3.Size = new System.Drawing.Size(90, 90);
            this.artb3.TabIndex = 3;
            this.artb3.Text = "";
            // 
            // trtb3
            // 
            this.trtb3.Location = new System.Drawing.Point(359, 11);
            this.trtb3.Name = "trtb3";
            this.trtb3.ReadOnly = true;
            this.trtb3.Size = new System.Drawing.Size(90, 90);
            this.trtb3.TabIndex = 5;
            this.trtb3.Text = "";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.jrtb4);
            this.panel4.Controls.Add(this.crtb4);
            this.panel4.Controls.Add(this.drtb4);
            this.panel4.Controls.Add(this.prtb4);
            this.panel4.Controls.Add(this.nrtb4);
            this.panel4.Controls.Add(this.hrtb4);
            this.panel4.Controls.Add(this.artb4);
            this.panel4.Controls.Add(this.trtb4);
            this.panel4.Location = new System.Drawing.Point(16, 403);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(925, 110);
            this.panel4.TabIndex = 20;
            // 
            // jrtb4
            // 
            this.jrtb4.Location = new System.Drawing.Point(823, 11);
            this.jrtb4.Name = "jrtb4";
            this.jrtb4.ReadOnly = true;
            this.jrtb4.Size = new System.Drawing.Size(90, 90);
            this.jrtb4.TabIndex = 18;
            this.jrtb4.Text = "";
            // 
            // crtb4
            // 
            this.crtb4.Location = new System.Drawing.Point(127, 11);
            this.crtb4.Name = "crtb4";
            this.crtb4.ReadOnly = true;
            this.crtb4.Size = new System.Drawing.Size(90, 90);
            this.crtb4.TabIndex = 6;
            this.crtb4.Text = "";
            // 
            // drtb4
            // 
            this.drtb4.Location = new System.Drawing.Point(243, 11);
            this.drtb4.Name = "drtb4";
            this.drtb4.ReadOnly = true;
            this.drtb4.Size = new System.Drawing.Size(90, 90);
            this.drtb4.TabIndex = 1;
            this.drtb4.Text = "";
            // 
            // prtb4
            // 
            this.prtb4.Location = new System.Drawing.Point(707, 11);
            this.prtb4.Name = "prtb4";
            this.prtb4.ReadOnly = true;
            this.prtb4.Size = new System.Drawing.Size(90, 90);
            this.prtb4.TabIndex = 2;
            this.prtb4.Text = "";
            // 
            // nrtb4
            // 
            this.nrtb4.Location = new System.Drawing.Point(11, 11);
            this.nrtb4.Name = "nrtb4";
            this.nrtb4.ReadOnly = true;
            this.nrtb4.Size = new System.Drawing.Size(90, 90);
            this.nrtb4.TabIndex = 0;
            this.nrtb4.Text = "";
            // 
            // hrtb4
            // 
            this.hrtb4.Location = new System.Drawing.Point(591, 11);
            this.hrtb4.Name = "hrtb4";
            this.hrtb4.ReadOnly = true;
            this.hrtb4.Size = new System.Drawing.Size(90, 90);
            this.hrtb4.TabIndex = 4;
            this.hrtb4.Text = "";
            // 
            // artb4
            // 
            this.artb4.Location = new System.Drawing.Point(475, 11);
            this.artb4.Name = "artb4";
            this.artb4.ReadOnly = true;
            this.artb4.Size = new System.Drawing.Size(90, 90);
            this.artb4.TabIndex = 3;
            this.artb4.Text = "";
            // 
            // trtb4
            // 
            this.trtb4.Location = new System.Drawing.Point(359, 11);
            this.trtb4.Name = "trtb4";
            this.trtb4.ReadOnly = true;
            this.trtb4.Size = new System.Drawing.Size(90, 90);
            this.trtb4.TabIndex = 5;
            this.trtb4.Text = "";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.jrtb5);
            this.panel5.Controls.Add(this.crtb5);
            this.panel5.Controls.Add(this.drtb5);
            this.panel5.Controls.Add(this.prtb5);
            this.panel5.Controls.Add(this.nrtb5);
            this.panel5.Controls.Add(this.hrtb5);
            this.panel5.Controls.Add(this.artb5);
            this.panel5.Controls.Add(this.trtb5);
            this.panel5.Location = new System.Drawing.Point(16, 519);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(925, 110);
            this.panel5.TabIndex = 21;
            // 
            // jrtb5
            // 
            this.jrtb5.Location = new System.Drawing.Point(823, 11);
            this.jrtb5.Name = "jrtb5";
            this.jrtb5.ReadOnly = true;
            this.jrtb5.Size = new System.Drawing.Size(90, 90);
            this.jrtb5.TabIndex = 18;
            this.jrtb5.Text = "";
            // 
            // crtb5
            // 
            this.crtb5.Location = new System.Drawing.Point(127, 11);
            this.crtb5.Name = "crtb5";
            this.crtb5.ReadOnly = true;
            this.crtb5.Size = new System.Drawing.Size(90, 90);
            this.crtb5.TabIndex = 6;
            this.crtb5.Text = "";
            // 
            // drtb5
            // 
            this.drtb5.Location = new System.Drawing.Point(243, 11);
            this.drtb5.Name = "drtb5";
            this.drtb5.ReadOnly = true;
            this.drtb5.Size = new System.Drawing.Size(90, 90);
            this.drtb5.TabIndex = 1;
            this.drtb5.Text = "";
            // 
            // prtb5
            // 
            this.prtb5.Location = new System.Drawing.Point(707, 11);
            this.prtb5.Name = "prtb5";
            this.prtb5.ReadOnly = true;
            this.prtb5.Size = new System.Drawing.Size(90, 90);
            this.prtb5.TabIndex = 2;
            this.prtb5.Text = "";
            // 
            // nrtb5
            // 
            this.nrtb5.Location = new System.Drawing.Point(11, 11);
            this.nrtb5.Name = "nrtb5";
            this.nrtb5.ReadOnly = true;
            this.nrtb5.Size = new System.Drawing.Size(90, 90);
            this.nrtb5.TabIndex = 0;
            this.nrtb5.Text = "";
            // 
            // hrtb5
            // 
            this.hrtb5.Location = new System.Drawing.Point(591, 11);
            this.hrtb5.Name = "hrtb5";
            this.hrtb5.ReadOnly = true;
            this.hrtb5.Size = new System.Drawing.Size(90, 90);
            this.hrtb5.TabIndex = 4;
            this.hrtb5.Text = "";
            // 
            // artb5
            // 
            this.artb5.Location = new System.Drawing.Point(475, 11);
            this.artb5.Name = "artb5";
            this.artb5.ReadOnly = true;
            this.artb5.Size = new System.Drawing.Size(90, 90);
            this.artb5.TabIndex = 3;
            this.artb5.Text = "";
            // 
            // trtb5
            // 
            this.trtb5.Location = new System.Drawing.Point(359, 11);
            this.trtb5.Name = "trtb5";
            this.trtb5.ReadOnly = true;
            this.trtb5.Size = new System.Drawing.Size(90, 90);
            this.trtb5.TabIndex = 5;
            this.trtb5.Text = "";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.jrtb6);
            this.panel6.Controls.Add(this.crtb6);
            this.panel6.Controls.Add(this.drtb6);
            this.panel6.Controls.Add(this.prtb6);
            this.panel6.Controls.Add(this.nrtb6);
            this.panel6.Controls.Add(this.hrtb6);
            this.panel6.Controls.Add(this.artb6);
            this.panel6.Controls.Add(this.trtb6);
            this.panel6.Location = new System.Drawing.Point(16, 635);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(925, 110);
            this.panel6.TabIndex = 22;
            // 
            // jrtb6
            // 
            this.jrtb6.Location = new System.Drawing.Point(823, 11);
            this.jrtb6.Name = "jrtb6";
            this.jrtb6.ReadOnly = true;
            this.jrtb6.Size = new System.Drawing.Size(90, 90);
            this.jrtb6.TabIndex = 18;
            this.jrtb6.Text = "";
            // 
            // crtb6
            // 
            this.crtb6.Location = new System.Drawing.Point(127, 11);
            this.crtb6.Name = "crtb6";
            this.crtb6.ReadOnly = true;
            this.crtb6.Size = new System.Drawing.Size(90, 90);
            this.crtb6.TabIndex = 6;
            this.crtb6.Text = "";
            // 
            // drtb6
            // 
            this.drtb6.Location = new System.Drawing.Point(243, 11);
            this.drtb6.Name = "drtb6";
            this.drtb6.ReadOnly = true;
            this.drtb6.Size = new System.Drawing.Size(90, 90);
            this.drtb6.TabIndex = 1;
            this.drtb6.Text = "";
            // 
            // prtb6
            // 
            this.prtb6.Location = new System.Drawing.Point(707, 11);
            this.prtb6.Name = "prtb6";
            this.prtb6.ReadOnly = true;
            this.prtb6.Size = new System.Drawing.Size(90, 90);
            this.prtb6.TabIndex = 2;
            this.prtb6.Text = "";
            // 
            // nrtb6
            // 
            this.nrtb6.Location = new System.Drawing.Point(11, 11);
            this.nrtb6.Name = "nrtb6";
            this.nrtb6.ReadOnly = true;
            this.nrtb6.Size = new System.Drawing.Size(90, 90);
            this.nrtb6.TabIndex = 0;
            this.nrtb6.Text = "";
            // 
            // hrtb6
            // 
            this.hrtb6.Location = new System.Drawing.Point(591, 11);
            this.hrtb6.Name = "hrtb6";
            this.hrtb6.ReadOnly = true;
            this.hrtb6.Size = new System.Drawing.Size(90, 90);
            this.hrtb6.TabIndex = 4;
            this.hrtb6.Text = "";
            // 
            // artb6
            // 
            this.artb6.Location = new System.Drawing.Point(475, 11);
            this.artb6.Name = "artb6";
            this.artb6.ReadOnly = true;
            this.artb6.Size = new System.Drawing.Size(90, 90);
            this.artb6.TabIndex = 3;
            this.artb6.Text = "";
            // 
            // trtb6
            // 
            this.trtb6.Location = new System.Drawing.Point(359, 11);
            this.trtb6.Name = "trtb6";
            this.trtb6.ReadOnly = true;
            this.trtb6.Size = new System.Drawing.Size(90, 90);
            this.trtb6.TabIndex = 5;
            this.trtb6.Text = "";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.jrtb7);
            this.panel7.Controls.Add(this.crtb7);
            this.panel7.Controls.Add(this.drtb7);
            this.panel7.Controls.Add(this.prtb7);
            this.panel7.Controls.Add(this.nrtb7);
            this.panel7.Controls.Add(this.hrtb7);
            this.panel7.Controls.Add(this.artb7);
            this.panel7.Controls.Add(this.trtb7);
            this.panel7.Location = new System.Drawing.Point(16, 751);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(925, 110);
            this.panel7.TabIndex = 23;
            // 
            // jrtb7
            // 
            this.jrtb7.Location = new System.Drawing.Point(823, 11);
            this.jrtb7.Name = "jrtb7";
            this.jrtb7.ReadOnly = true;
            this.jrtb7.Size = new System.Drawing.Size(90, 90);
            this.jrtb7.TabIndex = 18;
            this.jrtb7.Text = "";
            // 
            // crtb7
            // 
            this.crtb7.Location = new System.Drawing.Point(127, 11);
            this.crtb7.Name = "crtb7";
            this.crtb7.ReadOnly = true;
            this.crtb7.Size = new System.Drawing.Size(90, 90);
            this.crtb7.TabIndex = 6;
            this.crtb7.Text = "";
            // 
            // drtb7
            // 
            this.drtb7.Location = new System.Drawing.Point(243, 11);
            this.drtb7.Name = "drtb7";
            this.drtb7.ReadOnly = true;
            this.drtb7.Size = new System.Drawing.Size(90, 90);
            this.drtb7.TabIndex = 1;
            this.drtb7.Text = "";
            // 
            // prtb7
            // 
            this.prtb7.Location = new System.Drawing.Point(707, 11);
            this.prtb7.Name = "prtb7";
            this.prtb7.ReadOnly = true;
            this.prtb7.Size = new System.Drawing.Size(90, 90);
            this.prtb7.TabIndex = 2;
            this.prtb7.Text = "";
            // 
            // nrtb7
            // 
            this.nrtb7.Location = new System.Drawing.Point(11, 11);
            this.nrtb7.Name = "nrtb7";
            this.nrtb7.ReadOnly = true;
            this.nrtb7.Size = new System.Drawing.Size(90, 90);
            this.nrtb7.TabIndex = 0;
            this.nrtb7.Text = "";
            // 
            // hrtb7
            // 
            this.hrtb7.Location = new System.Drawing.Point(591, 11);
            this.hrtb7.Name = "hrtb7";
            this.hrtb7.ReadOnly = true;
            this.hrtb7.Size = new System.Drawing.Size(90, 90);
            this.hrtb7.TabIndex = 4;
            this.hrtb7.Text = "";
            // 
            // artb7
            // 
            this.artb7.Location = new System.Drawing.Point(475, 11);
            this.artb7.Name = "artb7";
            this.artb7.ReadOnly = true;
            this.artb7.Size = new System.Drawing.Size(90, 90);
            this.artb7.TabIndex = 3;
            this.artb7.Text = "";
            // 
            // trtb7
            // 
            this.trtb7.Location = new System.Drawing.Point(359, 11);
            this.trtb7.Name = "trtb7";
            this.trtb7.ReadOnly = true;
            this.trtb7.Size = new System.Drawing.Size(90, 90);
            this.trtb7.TabIndex = 5;
            this.trtb7.Text = "";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.jrtb8);
            this.panel8.Controls.Add(this.crtb8);
            this.panel8.Controls.Add(this.drtb8);
            this.panel8.Controls.Add(this.prtb8);
            this.panel8.Controls.Add(this.nrtb8);
            this.panel8.Controls.Add(this.hrtb8);
            this.panel8.Controls.Add(this.artb8);
            this.panel8.Controls.Add(this.trtb8);
            this.panel8.Location = new System.Drawing.Point(16, 867);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(925, 110);
            this.panel8.TabIndex = 24;
            // 
            // jrtb8
            // 
            this.jrtb8.Location = new System.Drawing.Point(823, 11);
            this.jrtb8.Name = "jrtb8";
            this.jrtb8.ReadOnly = true;
            this.jrtb8.Size = new System.Drawing.Size(90, 90);
            this.jrtb8.TabIndex = 18;
            this.jrtb8.Text = "";
            // 
            // crtb8
            // 
            this.crtb8.Location = new System.Drawing.Point(127, 11);
            this.crtb8.Name = "crtb8";
            this.crtb8.ReadOnly = true;
            this.crtb8.Size = new System.Drawing.Size(90, 90);
            this.crtb8.TabIndex = 6;
            this.crtb8.Text = "";
            // 
            // drtb8
            // 
            this.drtb8.Location = new System.Drawing.Point(243, 11);
            this.drtb8.Name = "drtb8";
            this.drtb8.ReadOnly = true;
            this.drtb8.Size = new System.Drawing.Size(90, 90);
            this.drtb8.TabIndex = 1;
            this.drtb8.Text = "";
            // 
            // prtb8
            // 
            this.prtb8.Location = new System.Drawing.Point(707, 11);
            this.prtb8.Name = "prtb8";
            this.prtb8.ReadOnly = true;
            this.prtb8.Size = new System.Drawing.Size(90, 90);
            this.prtb8.TabIndex = 2;
            this.prtb8.Text = "";
            // 
            // nrtb8
            // 
            this.nrtb8.Location = new System.Drawing.Point(11, 11);
            this.nrtb8.Name = "nrtb8";
            this.nrtb8.ReadOnly = true;
            this.nrtb8.Size = new System.Drawing.Size(90, 90);
            this.nrtb8.TabIndex = 0;
            this.nrtb8.Text = "";
            // 
            // hrtb8
            // 
            this.hrtb8.Location = new System.Drawing.Point(591, 11);
            this.hrtb8.Name = "hrtb8";
            this.hrtb8.ReadOnly = true;
            this.hrtb8.Size = new System.Drawing.Size(90, 90);
            this.hrtb8.TabIndex = 4;
            this.hrtb8.Text = "";
            // 
            // artb8
            // 
            this.artb8.Location = new System.Drawing.Point(475, 11);
            this.artb8.Name = "artb8";
            this.artb8.ReadOnly = true;
            this.artb8.Size = new System.Drawing.Size(90, 90);
            this.artb8.TabIndex = 3;
            this.artb8.Text = "";
            // 
            // trtb8
            // 
            this.trtb8.Location = new System.Drawing.Point(359, 11);
            this.trtb8.Name = "trtb8";
            this.trtb8.ReadOnly = true;
            this.trtb8.Size = new System.Drawing.Size(90, 90);
            this.trtb8.TabIndex = 5;
            this.trtb8.Text = "";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.titleLabel.Location = new System.Drawing.Point(843, 12);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(210, 46);
            this.titleLabel.TabIndex = 25;
            this.titleLabel.Text = "ProSportle";
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(866, 1008);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(75, 35);
            this.enterButton.TabIndex = 26;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click_1);
            // 
            // loginButton
            // 
            this.loginButton.Location = new System.Drawing.Point(32, 12);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(102, 36);
            this.loginButton.TabIndex = 27;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel6);
            this.panel9.Controls.Add(this.enterButton);
            this.panel9.Controls.Add(this.panel5);
            this.panel9.Controls.Add(this.guessBox);
            this.panel9.Controls.Add(this.panel4);
            this.panel9.Controls.Add(this.panel8);
            this.panel9.Controls.Add(this.panel3);
            this.panel9.Controls.Add(this.panel7);
            this.panel9.Controls.Add(this.panel2);
            this.panel9.Controls.Add(this.panel1);
            this.panel9.Controls.Add(this.picturePanel);
            this.panel9.Location = new System.Drawing.Point(472, 72);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(958, 1070);
            this.panel9.TabIndex = 28;
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(144F, 144F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1878, 1170);
            this.Controls.Add(this.loginButton);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.helpButton);
            this.Controls.Add(this.panel9);
            this.Name = "MainScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProSportle";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.picturePanel.ResumeLayout(false);
            this.picturePanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.ComboBox guessBox;
        private System.Windows.Forms.Panel picturePanel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label teamLabel;
        private System.Windows.Forms.Label divisionLabel;
        private System.Windows.Forms.Label conferenceLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox jrtb1;
        private System.Windows.Forms.RichTextBox crtb1;
        private System.Windows.Forms.RichTextBox drtb1;
        private System.Windows.Forms.RichTextBox prtb1;
        private System.Windows.Forms.RichTextBox nrtb1;
        private System.Windows.Forms.RichTextBox hrtb1;
        private System.Windows.Forms.RichTextBox artb1;
        private System.Windows.Forms.RichTextBox trtb1;
        private System.Windows.Forms.Label jerseyLabel;
        private System.Windows.Forms.Label positionlabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox jrtb2;
        private System.Windows.Forms.RichTextBox crtb2;
        private System.Windows.Forms.RichTextBox drtb2;
        private System.Windows.Forms.RichTextBox prtb2;
        private System.Windows.Forms.RichTextBox nrtb2;
        private System.Windows.Forms.RichTextBox hrtb2;
        private System.Windows.Forms.RichTextBox artb2;
        private System.Windows.Forms.RichTextBox trtb2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RichTextBox jrtb3;
        private System.Windows.Forms.RichTextBox crtb3;
        private System.Windows.Forms.RichTextBox drtb3;
        private System.Windows.Forms.RichTextBox prtb3;
        private System.Windows.Forms.RichTextBox nrtb3;
        private System.Windows.Forms.RichTextBox hrtb3;
        private System.Windows.Forms.RichTextBox artb3;
        private System.Windows.Forms.RichTextBox trtb3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RichTextBox jrtb4;
        private System.Windows.Forms.RichTextBox crtb4;
        private System.Windows.Forms.RichTextBox drtb4;
        private System.Windows.Forms.RichTextBox prtb4;
        private System.Windows.Forms.RichTextBox nrtb4;
        private System.Windows.Forms.RichTextBox hrtb4;
        private System.Windows.Forms.RichTextBox artb4;
        private System.Windows.Forms.RichTextBox trtb4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RichTextBox jrtb5;
        private System.Windows.Forms.RichTextBox crtb5;
        private System.Windows.Forms.RichTextBox drtb5;
        private System.Windows.Forms.RichTextBox prtb5;
        private System.Windows.Forms.RichTextBox nrtb5;
        private System.Windows.Forms.RichTextBox hrtb5;
        private System.Windows.Forms.RichTextBox artb5;
        private System.Windows.Forms.RichTextBox trtb5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RichTextBox jrtb6;
        private System.Windows.Forms.RichTextBox crtb6;
        private System.Windows.Forms.RichTextBox drtb6;
        private System.Windows.Forms.RichTextBox prtb6;
        private System.Windows.Forms.RichTextBox nrtb6;
        private System.Windows.Forms.RichTextBox hrtb6;
        private System.Windows.Forms.RichTextBox artb6;
        private System.Windows.Forms.RichTextBox trtb6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RichTextBox jrtb7;
        private System.Windows.Forms.RichTextBox crtb7;
        private System.Windows.Forms.RichTextBox drtb7;
        private System.Windows.Forms.RichTextBox prtb7;
        private System.Windows.Forms.RichTextBox nrtb7;
        private System.Windows.Forms.RichTextBox hrtb7;
        private System.Windows.Forms.RichTextBox artb7;
        private System.Windows.Forms.RichTextBox trtb7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RichTextBox jrtb8;
        private System.Windows.Forms.RichTextBox crtb8;
        private System.Windows.Forms.RichTextBox drtb8;
        private System.Windows.Forms.RichTextBox prtb8;
        private System.Windows.Forms.RichTextBox nrtb8;
        private System.Windows.Forms.RichTextBox hrtb8;
        private System.Windows.Forms.RichTextBox artb8;
        private System.Windows.Forms.RichTextBox trtb8;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Panel panel9;
    }
}